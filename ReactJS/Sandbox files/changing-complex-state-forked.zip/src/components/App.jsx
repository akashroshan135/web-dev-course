import React from "react";

function App() {
  const [fullName, setFullName] = React.useState({
    firstName: "",
    lastName: ""
  });

  function handleChange(event) {
    const { value, name } = event.target;
    setFullName(() => {
      if (name === "fName") {
        return {
          firstName: value,
          lastName: fullName.lastName
        };
      }
      if (name === "lName")
        return {
          firstName: fullName.firstName,
          lastName: value
        };
    });
  }

  return (
    <div className="container">
      <h1>
        Hello {fullName.firstName} {fullName.lastName}
      </h1>
      <form>
        <input name="fName" placeholder="First Name" onChange={handleChange} />
        <input name="lName" placeholder="Last Name" onChange={handleChange} />
        <button>Submit</button>
      </form>
    </div>
  );
}

export default App;
