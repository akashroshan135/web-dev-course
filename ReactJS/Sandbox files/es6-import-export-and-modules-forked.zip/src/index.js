import React from "react";
import ReactDOM from "react-dom";
import * as pie from "./math";
// import pie, { doublePi, tiplePi } from "./math";

ReactDOM.render(
  <ul>
    <li>{pie.default}</li>
    <li>{pie.doublePi()}</li>
    <li>{pie.tiplePi()}</li>
  </ul>,
  document.getElementById("root")
);
