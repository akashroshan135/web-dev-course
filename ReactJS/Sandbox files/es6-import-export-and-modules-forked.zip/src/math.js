const pi = 3.1415926;

function doublePi() {
  return pi * 2;
}

function tiplePi() {
  return pi * 3;
}

export default pi;
export { doublePi, tiplePi };
