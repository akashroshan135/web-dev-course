import React from "react";
import ReactDOM from "react-dom";

const imageSrc = "https://picsum.photos/200";

ReactDOM.render(
  <div>
    <h1 className="heading" contentEditable="true" spellCheck="false">
      My Favourite Foods
    </h1>
    {/* <ul>
      <li>Bacon</li>
      <li>Jamon</li>
      <li>Noodles</li>
    </ul> */}
    <div>
      <img
        src="https://picsum.photos/200?random=1"
        className="image"
        alt="image1"
      />
      <img
        src="https://picsum.photos/200?random=2"
        className="image"
        alt="image2"
      />
      <img src={imageSrc + "?greyscale"} className="image" alt="image3" />
    </div>
  </div>,
  document.getElementById("root")
);
